#include "bsp_cdc_usbx.h"

/* USBX��̬�ڴ���� */
#define USBX_MEMORY_SIZE            (32 * 1024)
#define USBX_APP_BYTE_POOL_SIZE     ((1024 * 10) + (USBX_MEMORY_SIZE))

static UX_SLAVE_CLASS_CDC_ACM_PARAMETER cdc_acm_parameter;
static uint8_t usbx_pool[USBX_APP_BYTE_POOL_SIZE];
volatile char fs_rx_buffer[1024] = {0};

extern PCD_HandleTypeDef hpcd_USB_OTG_FS;
extern UART_HandleTypeDef huart1;

static UX_SLAVE_CLASS_CDC_ACM *cdc_acm;

UART_HandleTypeDef *uart_handler;
//extern TX_EVENT_FLAGS_GROUP EventFlag;

UX_SLAVE_CLASS_CDC_ACM_LINE_CODING_PARAMETER CDC_VCP_LineCoding =
{
  115200, /* baud rate */
  0x00,   /* stop bits-1 */
  0x00,   /* parity - none */
  0x08    /* nb. of bits 8 */
};

VOID USBX_APP_UART_Init(UART_HandleTypeDef **huart)
{
  /* USER CODE BEGIN USBX_APP_UART_Init */
 // MX_USART1_UART_Init();
  *huart = &huart1;
  /* USER CODE END USBX_APP_UART_Init */
}

// ��CDC ACM���⴮�� ���������飨ȫ�٣�- ����Windows����CDC�������س�COM��
// ʶ��Ϊ�������豸��STM32 Virtual COM Port�����豸��������ʾCOM�˿�
unsigned char device_framework_fs[] = {

    // �豸������
    0x12,                           // bLength
    0x01,                           // bDescriptorType (Device)
    0x00, 0x02,                     // bcdUSB 2.00
    0xEF,                           // bDeviceClass (Miscellaneous Device Class)
    0x02,                           // bDeviceSubClass (Common Class)
    0x01,                           // bDeviceProtocol (Interface Association Descriptor)
    0x40,                           // bMaxPacketSize0 64 bytes
    0x83, 0x04,                     // idVendor (STMicroelectronics)
    0x10, 0x57,                     // idProduct
    0x00, 0x02,                     // bcdDevice 2.00
    0x01,                           // iManufacturer
    0x02,                           // iProduct
    0x03,                           // iSerialNumber
    0x01,                           // bNumConfigurations

    // ����������
    0x09,                           // bLength
    0x02,                           // bDescriptorType (Configuration)
    0x43, 0x00,                     // wTotalLength
    0x02,                           // bNumInterfaces
    0x01,                           // bConfigurationValue
    0x00,                           // iConfiguration
    0xC0,                           // bmAttributes (Self-powered)
    0x32,                           // bMaxPower 100mA

    // IAD - Interface Association Descriptor
    0x08,                           // bLength
    0x0B,                           // bDescriptorType (Interface Association)
    0x00,                           // bFirstInterface
    0x02,                           // bInterfaceCount
    0x02,                           // bFunctionClass (Communication Interface Class)
    0x02,                           // bFunctionSubClass (Abstract Control Model)
    0x01,                           // bFunctionProtocol (AT commands)
    0x00,                           // iFunction

    // �ӿ������� (CDC���ƽӿ�)
    0x09,                           // bLength
    0x04,                           // bDescriptorType (Interface)
    0x00,                           // bInterfaceNumber 0
    0x00,                           // bAlternateSetting
    0x01,                           // bNumEndpoints 1
    0x02,                           // bInterfaceClass (Communication Interface Class)
    0x02,                           // bInterfaceSubClass (Abstract Control Model)
    0x01,                           // bInterfaceProtocol (AT Commands)
    0x00,                           // iInterface

    // CDC��ͷ����������
    0x05,                           // bLength
    0x24,                           // bDescriptorType (CS_INTERFACE)
    0x00,                           // bDescriptorSubtype (Header Function Descriptor)
    0x10, 0x01,                     // bcdCDC 1.10

    // CDC���й�������������
    0x05,                           // bLength
    0x24,                           // bDescriptorType (CS_INTERFACE)
    0x01,                           // bDescriptorSubtype (Call Management)
    0x00,                           // bmCapabilities (D0: No call management, D1: No data interface)
    0x01,                           // bDataInterface

    // CDC������ƹ�������������
    0x04,                           // bLength
    0x24,                           // bDescriptorType (CS_INTERFACE)
    0x02,                           // bDescriptorSubtype (Abstract Control Management)
    0x02,                           // bmCapabilities (Set_Line_Coding, Set_Control_Line_State)

    // CDC���Ͻӿ�������
    0x05,                           // bLength
    0x24,                           // bDescriptorType (CS_INTERFACE)
    0x06,                           // bDescriptorSubtype (Union Functional Descriptor)
    0x00,                           // bMasterInterface (Control Interface)
    0x01,                           // bSlaveInterface0 (Data Interface)

    // �˵������� (�ж϶˵�)
    0x07,                           // bLength
    0x05,                           // bDescriptorType (Endpoint)
    0x81,                           // bEndpointAddress (IN/D2H)
    0x03,                           // bmAttributes (Interrupt)
    0x10, 0x00,                     // wMaxPacketSize 16
    0xFF,                           // bInterval 255ms

    // �ӿ������� (CDC���ݽӿ�)
    0x09,                           // bLength
    0x04,                           // bDescriptorType (Interface)
    0x01,                           // bInterfaceNumber 1
    0x00,                           // bAlternateSetting
    0x02,                           // bNumEndpoints 2
    0x0A,                           // bInterfaceClass (Data Interface Class)
    0x00,                           // bInterfaceSubClass (None)
    0x00,                           // bInterfaceProtocol (None)
    0x00,                           // iInterface

    // �˵������� (����OUT�˵�)
    0x07,                           // bLength
    0x05,                           // bDescriptorType (Endpoint)
    0x02,                           // bEndpointAddress (OUT/H2D)
    0x02,                           // bmAttributes (Bulk)
    0x40, 0x00,                     // wMaxPacketSize 64
    0x00,                           // bInterval

    // �˵������� (����IN�˵�)
    0x07,                           // bLength
    0x05,                           // bDescriptorType (Endpoint)
    0x83,                           // bEndpointAddress (IN/D2H)
    0x02,                           // bmAttributes (Bulk)
    0x40, 0x00,                     // wMaxPacketSize 64
    0x00,                           // bInterval
};

static VOID USBD_CDC_VCP_Config(UX_SLAVE_CLASS_CDC_ACM_LINE_CODING_PARAMETER
                                *CDC_VCP_LineCoding)
{
//  /* Deinitialization UART */
//  if (HAL_UART_DeInit(uart_handler) != HAL_OK)
//  {
//    /* Deinitialization Error */
//    Error_Handler();
//  }

  /* Check stop bit parameter */
  switch (CDC_VCP_LineCoding->ux_slave_class_cdc_acm_parameter_stop_bit)
  {
    case 0:

      /* Set the UART Stop bit to 1 */
      uart_handler->Init.StopBits = UART_STOPBITS_1;

      break;

    case 2:

      /* Set the UART Stop bit to 2 */
      uart_handler->Init.StopBits = UART_STOPBITS_2;

      break;

    default :

      /* By default set the UART Stop bit to 1 */
      uart_handler->Init.StopBits = UART_STOPBITS_1;

      break;
  }

  /* Check parity parameter */
  switch (CDC_VCP_LineCoding->ux_slave_class_cdc_acm_parameter_parity)
  {
    case 0:

      /* Set the UART parity bit to none */
      uart_handler->Init.Parity = UART_PARITY_NONE;

      break;

    case 1:

      /* Set the UART parity bit to ODD */
      uart_handler->Init.Parity = UART_PARITY_ODD;

      break;

    case 2:

      /* Set the UART parity bit to even */
      uart_handler->Init.Parity = UART_PARITY_EVEN;

      break;

    default :

      /* By default set the UART parity bit to none */
      uart_handler->Init.Parity = UART_PARITY_NONE;

      break;
  }

  /* Set the UART data type : only 8bits and 9bits is supported */
  switch (CDC_VCP_LineCoding->ux_slave_class_cdc_acm_parameter_data_bit)
  {
    case 0x07:

      /* With this configuration a parity (Even or Odd) must be set */
      uart_handler->Init.WordLength = UART_WORDLENGTH_8B;

      break;

    case 0x08:

      if (uart_handler->Init.Parity == UART_PARITY_NONE)
      {
        uart_handler->Init.WordLength = UART_WORDLENGTH_8B;
      }
      else
      {
        uart_handler->Init.WordLength = UART_WORDLENGTH_9B;
      }

      break;

    default :

      uart_handler->Init.WordLength = UART_WORDLENGTH_8B;

      break;
  }

//  /* Get the UART baudrate from vcp */
//  uart_handler->Init.BaudRate = CDC_VCP_LineCoding->ux_slave_class_cdc_acm_parameter_baudrate;

//  /* Set the UART Hw flow control to none */
//  uart_handler->Init.HwFlowCtl = UART_HWCONTROL_NONE;

//  /* Set the UART mode */
//  uart_handler->Init.Mode = UART_MODE_TX_RX;

//  /* Set the UART sampling */
//  uart_handler->Init.OverSampling = UART_OVERSAMPLING_16;

//  /* Initialization UART */
//  if (HAL_UART_Init(uart_handler) != HAL_OK)
//  {
//    /* Initialization Error */
//    Error_Handler();
//  }

//  /* Start reception: provide the buffer pointer with offset and the buffer size */
//  HAL_UART_Receive_IT(uart_handler, (uint8_t *)(UserTxBufferFS + UserTxBufPtrIn), 1);
}

/* ʵ������ص����� */
/**
  * @brief  my_cdc_acm_activate
  *         This function is called when insertion of a CDC ACM device.
  * @param  cdc_acm_instance: Pointer to the cdc acm class instance.
  * @retval none
  */
void my_cdc_acm_activate(VOID *cdc_acm_instance)
{
    /* ����ʵ����� */
    cdc_acm = (UX_SLAVE_CLASS_CDC_ACM *)cdc_acm_instance;
    
//    printf("CDC ACM Activated\r\n");
    
    // ���ö�д�ص�����
//		USBX_APP_UART_Init(UART_HandleTypeDef **huart)
		CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_baudrate = 115200;

  /* Set the UART data type : only 8bits and 9bits are supported */
  switch (uart_handler->Init.WordLength)
  {
    case UART_WORDLENGTH_8B:
    {
      /* Set UART data bit to 8 */
      CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_data_bit = 8;
      break;
    }

    case UART_WORDLENGTH_9B:
    {
      /* Set UART data bit to 9 */
      CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_data_bit = 9;
      break;
    }

    default :
    {
      /* By default set UART data bit to 8 */
      CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_data_bit = 8;
      break;
    }
	}
	
	/* Get UART Parity */
  CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_parity = uart_handler->Init.Parity;

  /* Get UART StopBits */
  CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_stop_bit = uart_handler->Init.StopBits;
	
	/* Set device class_cdc_acm with default parameters */
  if (ux_device_class_cdc_acm_ioctl(cdc_acm, UX_SLAVE_CLASS_CDC_ACM_IOCTL_SET_LINE_CODING,
                                    &CDC_VCP_LineCoding) != UX_SUCCESS)
  {
    Error_Handler();
  }
}

/* ʵ��ȥ����ص����� */
/**
  * @brief  my_cdc_acm_deactivate
  *         This function is called when extraction of a CDC ACM device.
  * @param  cdc_acm_instance: Pointer to the cdc acm class instance.
  * @retval none
  */
static VOID my_cdc_acm_deactivate(VOID *cdc_acm_instance)
{ 
    /* ���Խ��������������� */
	/* USER CODE BEGIN USBD_CDC_ACM_Deactivate */
  UX_PARAMETER_NOT_USED(cdc_acm_instance);

  /* Reset the cdc acm instance */
  cdc_acm = UX_NULL;

  return;
}

/* �����ı�ص����� */
/**
  * @brief  my_cdc_acm_parameter_change
  *         This function is invoked to manage the CDC ACM class requests.
  * @param  cdc_acm_instance: Pointer to the cdc acm class instance.
  * @retval none
  */
void my_cdc_acm_parameter_change(VOID *cdc_acm_instance)
{
  /* USER CODE BEGIN USBD_CDC_ACM_ParameterChange */
  UX_PARAMETER_NOT_USED(cdc_acm_instance);

  ULONG request;
  UX_SLAVE_TRANSFER *transfer_request;
  UX_SLAVE_DEVICE *device;

  /* Get the pointer to the device.  */
  device = &_ux_system_slave -> ux_system_slave_device;

  /* Get the pointer to the transfer request associated with the control endpoint. */
  transfer_request = &device -> ux_slave_device_control_endpoint.ux_slave_endpoint_transfer_request;

  request = *(transfer_request -> ux_slave_transfer_request_setup + UX_SETUP_REQUEST);

  switch (request)
  {
    case UX_SLAVE_CLASS_CDC_ACM_SET_LINE_CODING :

      /* Get the Line Coding parameters */
      if (ux_device_class_cdc_acm_ioctl(cdc_acm, UX_SLAVE_CLASS_CDC_ACM_IOCTL_GET_LINE_CODING,
                                        &CDC_VCP_LineCoding) != UX_SUCCESS)
      {
        Error_Handler();
      }

      /* Check if baudrate < 9600) then set it to 9600 */
      if (CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_baudrate < 9600)
      {
        CDC_VCP_LineCoding.ux_slave_class_cdc_acm_parameter_baudrate = 9600;

        /* Set the new configuration of ComPort */
        USBD_CDC_VCP_Config(&CDC_VCP_LineCoding);
      }
      else
      {
        /* Set the new configuration of ComPort */
        USBD_CDC_VCP_Config(&CDC_VCP_LineCoding);
      }

      break;

    case UX_SLAVE_CLASS_CDC_ACM_GET_LINE_CODING :

      /* Set the Line Coding parameters */
      if (ux_device_class_cdc_acm_ioctl(cdc_acm, UX_SLAVE_CLASS_CDC_ACM_IOCTL_SET_LINE_CODING,
                                        &CDC_VCP_LineCoding) != UX_SUCCESS)
      {
        Error_Handler();
      }

      break;

    case UX_SLAVE_CLASS_CDC_ACM_SET_CONTROL_LINE_STATE :
    default :
      break;
  }

  /* USER CODE END USBD_CDC_ACM_ParameterChange */

  return;
}



UINT  status =  UX_SUCCESS;
void BSP_cdc_full_speed_usbx_init(void)
{
	
	
	ULONG device_framework_hs_length;
	ULONG device_framework_fs_length;
	ULONG string_framework_length;
	ULONG languge_id_framework_length;
	UCHAR *device_framework_high_speed;
	UCHAR *device_framework_full_speed;
	UCHAR *string_framework;
	UCHAR *language_id_framework;
	
	// ����RX FIFO������FIFO���Ĵ�С
	HAL_PCDEx_SetRxFiFo(&hpcd_USB_OTG_FS, 0x200); // �ɸ�����Ҫ������С������512�ֽ�
	// ����TX FIFO������FIFO���Ĵ�С��ÿ���˵��������
	HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 0, 0x40);   // ���ƶ˵�0
	HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 1, 0x100);  // CDC����IN�˵㣨����0x81��
	HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 2, 0x100);  // CDC�ж�IN�˵㣨����0x83��
	
	ux_system_initialize(usbx_pool, USBX_MEMORY_SIZE, UX_NULL, 0);
	
	device_framework_high_speed = USBD_Get_Device_Framework_Speed(USBD_HIGH_SPEED, &device_framework_hs_length);
	device_framework_full_speed = USBD_Get_Device_Framework_Speed(USBD_FULL_SPEED, &device_framework_fs_length);
	string_framework = USBD_Get_String_Framework(&string_framework_length);
	language_id_framework = USBD_Get_Language_Id_Framework(&languge_id_framework_length);
	
	status =  ux_device_stack_initialize(device_framework_high_speed,
																	device_framework_hs_length,
																	device_framework_full_speed,
																	device_framework_fs_length,
																	string_framework,
																	string_framework_length,
																	language_id_framework,
																	languge_id_framework_length, UX_NULL);
	if (status != UX_SUCCESS)
	{
			return;
	}
	
//	MX_USB_OTG_FS_PCD_Init();
	
	
	/* �����������豸ʱ��USBX����ô˺�����ͨ�����������Ӧ�ò�ĳ�ʼ�� */
	cdc_acm_parameter.ux_slave_class_cdc_acm_instance_activate = my_cdc_acm_activate;

	/* ������ȡ�����ã����豸�Ͽ���ʱ�����ã�������Դ����) */
	cdc_acm_parameter.ux_slave_class_cdc_acm_instance_deactivate = my_cdc_acm_deactivate;

	/* �������޸���·���루�粨���ʣ�ʱ���� */
	cdc_acm_parameter.ux_slave_class_cdc_acm_parameter_change = my_cdc_acm_parameter_change;


	/* 3. ע��CDC ACM�ൽUSB�豸ջ */
	/* �������壺�����ơ�����ں����������������ӿڱ�š������ṹ��ָ�� */
	status = ux_device_stack_class_register(_ux_system_slave_class_cdc_acm_name,
																					ux_device_class_cdc_acm_entry,
																					1, 0, (VOID *)&cdc_acm_parameter);
                                                                                  
	if (status != UX_SUCCESS)
	{
			return;
	}	
		
	status =  ux_dcd_stm32_initialize((ULONG)USB_OTG_FS, (ULONG)&hpcd_USB_OTG_FS);

	if (status != UX_SUCCESS)
	{
			return;
	}
	
//	MX_USB_OTG_FS_PCD_Init();	
	HAL_PCD_Start(&hpcd_USB_OTG_FS);

//      MX_USB_OTG_FS_PCD_Init();
//			HAL_PCDEx_SetRxFiFo(&hpcd_USB_OTG_FS, 0x100); // �ɸ�����Ҫ������С������512�ֽ�
//			// ����TX FIFO������FIFO���Ĵ�С��ÿ���˵��������
//			HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 0, 0x40);   // ���ƶ˵�0
//			HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 1, 0x100);  // CDC����IN�˵㣨����0x81��
//			HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 2, 0x100);  // CDC�ж�IN�˵㣨����0x83��
//      ux_dcd_stm32_initialize((ULONG)USB_OTG_FS, (ULONG)&hpcd_USB_OTG_FS);
//      HAL_PCD_Start(&hpcd_USB_OTG_FS);

}

/**
  * @brief  Function implementing usbx_cdc_acm_thread_entry.
  * @param  thread_input: Not used
  * @retval none
  */
VOID CDC_ACM_Read_Task(VOID)
{
  UX_SLAVE_DEVICE *device;
  UX_SLAVE_INTERFACE *data_interface;
  UX_SLAVE_CLASS_CDC_ACM *cdc_acm;
  UINT  status;
  ULONG read_length;
  static ULONG actual_length;
	static UINT read_state = UX_STATE_RESET;
	static volatile ULONG EventFlag = 0;

  /* Get device */
  device = &_ux_system_slave->ux_system_slave_device;

  /* Check if device is configured */
  if (device->ux_slave_device_state != UX_DEVICE_CONFIGURED)
  {
    read_state = UX_STATE_RESET;
    return;
  }

  /* Get Data interface (interface 1) */
  data_interface = device->ux_slave_device_first_interface->ux_slave_interface_next_interface;
  cdc_acm =  data_interface->ux_slave_interface_class_instance;
  read_length = (_ux_system_slave->ux_system_slave_speed == UX_HIGH_SPEED_DEVICE) ? 512 : 64;

  /* Run state machine.  */
  switch(read_state)
  {
    case UX_STATE_RESET:
      read_state = UX_STATE_WAIT;
      /* Fall through.  */
    case UX_STATE_WAIT:
      status = ux_device_class_cdc_acm_read(cdc_acm,
                                                (UCHAR *)fs_rx_buffer, read_length,
                                                &actual_length);
      /* Error.  */
      if (status <= UX_STATE_ERROR)
      {
        /* Reset state.  */
        read_state = UX_STATE_RESET;
        return;
      }
      if (status == UX_STATE_NEXT)
      {
        if (actual_length != 0)
        {
          read_state = APP_CDC_ACM_READ_STATE_TX_START;
        }
        else
        {
          read_state = UX_STATE_RESET;
        }
        return;
      }
      /* Wait.  */
      return;
    case APP_CDC_ACM_READ_STATE_TX_START:
      /* Send the data via UART */
//      status = HAL_UART_Transmit_DMA(uart_handler, (uint8_t *)fs_rx_buffer,
//                                      actual_length);
//      if (status == HAL_BUSY)
//      {
//        /* Keep trying.  */
//        return;
//      }
//      if (status != HAL_OK)
//      {
//        /* Transfer error in reception process */
//        Error_Handler();
//      }
      /* DMA started.  */
      read_state = APP_CDC_ACM_READ_STATE_TX_WAIT;
      /* Fall through.  */
    case APP_CDC_ACM_READ_STATE_TX_WAIT:
      if (EventFlag & TX_NEW_TRANSMITTED_DATA)
      {
        EventFlag &= ~TX_NEW_TRANSMITTED_DATA;
      }
      read_state = UX_STATE_WAIT;
      return;
    default:
      return;
  }
}




static UCHAR fs_tx_buffer[1024];
static UX_SLAVE_CLASS_CDC_ACM *cdc_acm_instance = NULL;

/* CDC ACM ��ȡ���� - �����汾 */
VOID CDC_ACM_Read_Task_test(VOID)
{
    static UINT read_state = UX_STATE_RESET;
    static ULONG actual_length = 0;
    static ULONG read_length = 64;  // ȫ��ģʽ
    
    UINT status;
    UX_SLAVE_DEVICE *device;
    UX_SLAVE_INTERFACE *data_interface;
    
    /* ��ȡ�豸 */
    device = &_ux_system_slave->ux_system_slave_device;
    
    /* ����豸�Ƿ������� */
    if (device->ux_slave_device_state != UX_DEVICE_CONFIGURED)
    {
        read_state = UX_STATE_RESET;
        return;
    }
    
    /* ��ȡ���ݽӿڣ��ӿ�1�� */
    if (device->ux_slave_device_first_interface == UX_NULL)
    {
        return;
    }
    
    data_interface = device->ux_slave_device_first_interface->ux_slave_interface_next_interface;
    if (data_interface == UX_NULL)
    {
        return;
    }
    
    /* ��ȡCDC ACMʵ�� */
    cdc_acm_instance = (UX_SLAVE_CLASS_CDC_ACM *)data_interface->ux_slave_interface_class_instance;
    if (cdc_acm_instance == UX_NULL)
    {
        return;
    }
    
    /* �����ٶ����ö�ȡ���� */
    if (_ux_system_slave->ux_system_slave_speed == UX_HIGH_SPEED_DEVICE)
    {
        read_length = 512;
    }
    else
    {
        read_length = 64;
    }
    
    /* ����״̬�� */
    switch (read_state)
    {
        case UX_STATE_RESET:
            read_state = UX_STATE_RESET;
            /* ����ִ�� */
            
        case APP_CDC_ACM_READ_STATE_TX_WAIT:
            /* ������ȡ���� */
            status = ux_device_class_cdc_acm_read(cdc_acm_instance,
                                                  (UCHAR *)fs_rx_buffer,
                                                  read_length,
                                                  &actual_length);
            
            /* ���״̬ */
            if (status == UX_SUCCESS)
            {
                /* ��ȡ�����ѽ��ܣ��ȴ����� */
                read_state = APP_CDC_ACM_READ_STATE_TX_WAIT;
            }
            else if (status == UX_TRANSFER_NO_ANSWER)
            {
                /* û�����ݣ����ֵȴ�״̬ */
                return;
            }
            else if (status == UX_STATE_IDLE)
            {
                /* ��ȡ��ɣ������� */
                if (actual_length > 0)
                {
                    read_state = APP_CDC_ACM_READ_STATE_TX_START;
                }
                else
                {
                    /* �㳤�Ȱ�������������ȡ */
                    read_state = UX_STATE_WAIT;
                }
            }
            else
            {
                /* ��������״̬ */
                read_state = UX_STATE_RESET;
            }
            break;
            
        case APP_CDC_ACM_READ_STATE_TX_START:
            /* �������յ������� */
            if (actual_length > 0)
            {
                /* �������ݣ���ѡ�� */
                ULONG write_actual_length;
                status = ux_device_class_cdc_acm_write(cdc_acm_instance,
                                                       (UCHAR *)fs_rx_buffer,
                                                       actual_length,
                                                       &write_actual_length);
                
                if (status != UX_SUCCESS)
                {
                    /* д��ʧ�ܣ�����Ȼ������ȡ */
                }
            }
            
            /* ���ص��ȴ�״̬��׼����һ�ζ�ȡ */
            read_state = UX_STATE_WAIT;
            break;
            
        default:
            read_state = UX_STATE_RESET;
            break;
    }
}