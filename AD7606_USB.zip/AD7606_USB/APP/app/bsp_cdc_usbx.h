#ifndef __BSP_CDC_USBX_H__
#define __BSP_CDC_USBX_H__

#include <stdint.h>

#include "usb_otg.h"
#include "ux_api.h"
#include "ux_system.h"
#include "ux_utility.h"
#include "ux_device_stack.h"
#include "ux_dcd_stm32.h"
#include "ux_device_descriptors.h"
#include "ux_device_class_storage.h"
#include "ux_device_descriptors.h"
//#include "ux_device_msc.h"
//#include "tx_execution_profile.h"
#include "ux_api.h"
#include "ux_device_class_cdc_acm.h"
#include "ux_device_stack.h"
#include "ux_device_cdc_acm.h"

#define APP_CDC_ACM_READ_STATE_TX_START  (UX_STATE_APP_STEP + 0)
#define APP_CDC_ACM_READ_STATE_TX_WAIT   (UX_STATE_APP_STEP + 1)

/* Rx/TX flag */
#define RX_NEW_RECEIVED_DATA      0x01
#define TX_NEW_TRANSMITTED_DATA   0x02

void BSP_cdc_full_speed_usbx_init(void);
VOID CDC_ACM_Read_Task(VOID);
VOID CDC_ACM_Read_Task_test(VOID);

#endif

