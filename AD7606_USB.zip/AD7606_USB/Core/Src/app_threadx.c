/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_threadx.c
  * @author  MCD Application Team
  * @brief   ThreadX applicative file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_threadx.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp_cdc_usbx.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
//#define THREAD_STACK_SIZE  1024  // ���������ջ��С
//#define THREAD_PRIORITY    15    // �������ȼ�

//static TX_THREAD my_thread;      // ������ƿ�
//static uint8_t thread_stack[THREAD_STACK_SIZE];  // �����ջ�ռ�

//// ������ں���
//void my_thread_entry(ULONG initial_input)
//{
//    while (1) 
//    {
//        HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_9);  
//        tx_thread_sleep(500);  
//    }
//}

// UINT app_status = 1;

//void tx_application_define(void *first_unused_memory)
//{
//   

//    // ��������
//    app_status = tx_thread_create(&my_thread,         
//                             "My Thread",        
//                             my_thread_entry,     
//                             0x1234,            
//                             &thread_stack[0],       
//                             THREAD_STACK_SIZE,   
//                             THREAD_PRIORITY,    
//                             THREAD_PRIORITY,    
//                             TX_NO_TIME_SLICE,                 
//                             TX_AUTO_START);     

//    if (app_status != TX_SUCCESS)
//    {
//        
//    }
//}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/**
  * @brief  Application ThreadX Initialization.
  * @param memory_ptr: memory pointer
  * @retval int
  */
UINT App_ThreadX_Init(VOID *memory_ptr)
{
  UINT ret = TX_SUCCESS;
  TX_BYTE_POOL *byte_pool = (TX_BYTE_POOL*)memory_ptr;

  /* USER CODE BEGIN App_ThreadX_Init */
  (void)byte_pool;
  /* USER CODE END App_ThreadX_Init */

  return ret;
}

/**
  * @brief  MX_ThreadX_Init
  * @param  None
  * @retval None
  */
void MX_ThreadX_Init(void)
{
  /* USER CODE BEGIN  Before_Kernel_Start */
//	BSP_cdc_full_speed_usbx_init();
//	app_status = tx_thread_create(&my_thread,         
//													 "My Thread",        
//													 my_thread_entry,     
//													 0x1234,            
//													 &thread_stack[0],       
//													 THREAD_STACK_SIZE,   
//													 THREAD_PRIORITY,    
//													 THREAD_PRIORITY,    
//													 TX_NO_TIME_SLICE,                 
//													 TX_AUTO_START);
  /* USER CODE END  Before_Kernel_Start */

  tx_kernel_enter();

  /* USER CODE BEGIN  Kernel_Start_Error */

  /* USER CODE END  Kernel_Start_Error */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
